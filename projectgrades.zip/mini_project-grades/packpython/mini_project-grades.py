'''
mohammed sayaim 
started 3/25 
ended 3/28 
description:this program will ask a user for their grades, then gives the letter grade equivalent, grade scale equivalent and average. 
'''
def askgrade(): 
    global numgrades , listgrades
    numgrades= float(input("how many grades are you inputing:")) 
    checknumgrades= numgrades % 1 
    if (numgrades < 0 or checknumgrades !=0): 
        print("please input a positive whole number")
        askgrade() 
    else: 
        listgrade() 
def listgrade(): 
    countergrades= 1 
    listgrades= ""
    listletters= "" 
    gpa= ""
    sum=0 
    gpaaverage=0
    while(countergrades <= numgrades): 
        userinput= float(input("please input grade(0-100):"))
        if (userinput > -1 and userinput < 101): 
            listgrades= [listgrades, userinput]
            sum= sum + userinput  
            if (userinput >=90 and userinput <= 100):
                listletters= [listletters,"A"] 
                gpa= [gpa, "4.0"]
                gpaaverage= gpaaverage + 4
            if (userinput >=80 and userinput<90): 
                listletters= [listletters, "B"] 
                gpa= [gpa, "3.0"]
                gpaaverage= gpaaverage + 3
            if (userinput >=70 and userinput <80):
                listletters= [listletters,"C"] 
                gpa= [gpa, "2.0"]
                gpaaverage= gpaaverage + 2
            if (userinput >=60 and userinput<70): 
                listletters= [listletters, "D"] 
                gpa= [gpa, "1.0"]
                gpaaverage= gpaaverage + 1
            if (userinput < 60):
                listletters= [listletters,"F"]
                gpa= [gpa, "0.0"]
                gpaaverage= gpaaverage + 0 
            countergrades= countergrades + 1 
        else: 
            print("please input a positive number between 0-100")
    
    average= sum/numgrades
    gpaaverage=gpaaverage/numgrades
    print("average:" + str(average))
    print("grades:" + str(listgrades))
    print("letter grades:" + str(listletters)) 
    print("individual gpa:" + str(gpa)) 
    print("gpa average:" + str(gpaaverage))






def main(): 
    askgrade()

if __name__=="__main__": 
    main()