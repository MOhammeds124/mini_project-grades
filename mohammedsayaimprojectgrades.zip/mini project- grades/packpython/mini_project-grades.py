'''
mohammed sayaim 
started 3/25 
ended 3/28 
description: this program will ask a user for their grades, then gives the letter grade equivalent, grade scale equivalent and average. 
'''

def askgrade():  
    global numgrades
    numgrades= float(input("how many grades are you inputting:")) 
    checknumgrades= numgrades % 1    
    if (numgrades < 0  or checknumgrades != 0 ): 
        print("please input a positive whole number")
        askgrade() 
    else: 
        listgrade() 
def listgrade(): 
    countergrades= 1
    listgrades= [] 
    while(countergrades <= numgrades): 
        userinput= float(input("please input grade"))
        if (userinput > -1 and userinput < 101): 
            listgrades= [listgrades,userinput] 
            countergrades= countergrades + 1 
        
        





















def main(): 
    global numgrades,listgrades
    askgrade() 

if __name__=="__main__": 
    main()